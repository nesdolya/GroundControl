# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ndscheduler',
 'ndscheduler.corescheduler',
 'ndscheduler.corescheduler.core',
 'ndscheduler.corescheduler.datastore',
 'ndscheduler.corescheduler.datastore.providers',
 'ndscheduler.server',
 'ndscheduler.server.handlers']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'ndscheduler-edited',
    'version': '0.1.0',
    'description': "'Changes to Next Door ndscheduler https://github.com/Nextdoor/ndscheduler for SoundScape Analytics'",
    'long_description': "# ndscheduler edited\nNext Door's ndscheduler has been edited for SoundScape Analytics needs.\nBy Andrea Nesdoly (andreanesdoly@gmail.com) & SoundScape Analytics (benhendricks@soundspace-analytics.ca)\nFebruary 2023\n\n",
    'author': 'Andrea Nesdoly',
    'author_email': 'andreanesdoly@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8.0',
}


setup(**setup_kwargs)
