"""Init file for datastore library"""
