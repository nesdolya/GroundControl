# ndscheduler edited
Next Door's ndscheduler has been edited for SoundScape Analytics needs.
By Andrea Nesdoly (andreanesdoly@gmail.com) & SoundScape Analytics (benhendricks@soundspace-analytics.ca)
February 2023

