"""Init file for core library"""
