"""A reference implementation of a scheduler."""
