# GroundControl

GroundControl is a customized Python library that builds a cron-like system to schedule jobs. It is a modification of [NDScheduler](https://github.com/Nextdoor/ndscheduler), which manages the cron-like system through a web-based user interface. GroundControl requires Python ≥ 3.0 or <3.10 and assumes the user has some programming knowledge and can run Python scripts in the command terminal. 

