# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['schedulerss', 'schedulerss.jobs']

package_data = \
{'': ['*'], 'schedulerss': ['dependencies/*']}

install_requires = \
['APScheduler>=3.0.0',
 'SQLAlchemy==1.4.41',
 'future==0.18.3',
 'ndscheduler_edited @ '
 'file:///home/neztech/SoundScape_ndscheduler/SchedulerSS_v12/schedulerss/dependencies/ndscheduler_edited-0.1.0.tar.gz',
 'python-dateutil>=2.8.2',
 'requests>=2.28',
 'tinyscript>=1.26.21',
 'tornado==5.1.1']

setup_kwargs = {
    'name': 'schedulerss',
    'version': '0.1.2',
    'description': 'SoundScape Analytics job scheduler application based on Next Door ndscheduler',
    'long_description': '# SchedulerSS\n\nSchedulerSS is a customized Python library that builds a cron-like system to schedule jobs. It is a modification of [NDScheduler](https://github.com/Nextdoor/ndscheduler), which manages the cron-like system through a web-based user interface. SchedulerSS requires Python ≥ 3.0 and assumes the user has some programming knowledge and can run Python scripts in the command terminal. \n\n',
    'author': 'Andrea Nesdoly',
    'author_email': 'andreanesdoly@gmail.com>,SoundSpace Analytics <benhendricks@soundspace-analytics.ca',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
